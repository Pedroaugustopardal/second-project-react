# Front-end com React.JS

Neste projeto foi desenvolvido uma página simples que trabalha junto com um back-end desenvolvido.

**Para executar este projeto, você precisará que o projeto do back-end esteja em execução. Instale as libs com o comando **yarn** e execute o projeto com o comando **yarn dev***

Com o projeto em execução, acesse do seu browser http://localhost:8080/

Este projeto cria um novo item em nossa lista do back-end por meio do botão "Adicionar Projeto".
